<template>
  <div class="home">
    <el-button @click="getAjax" type="primary" icon="el-icon-edit"></el-button>
    <el-button type="primary" icon="el-icon-share"></el-button>
    <el-button type="primary" icon="el-icon-delete"></el-button>
    <el-button type="primary" icon="el-icon-search">搜索</el-button>
    <el-button type="primary">上传<i class="el-icon-upload el-icon--right"></i></el-button>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'
import axios from 'axios'

export default {
  name: 'hello',
  methods: {
    fn() {
      console.log(123)
    },
    getAjax() {
      // axios.get('https://api.leijiuling.com/get').then((res) => {
      axios.get('/api/get').then((res) => {
        console.log('成功：', res)
      })
    }
  },
  components: {
    HelloWorld
  }
}
</script>

module.exports = {
  root: true,
  env: {
    node: true
  },
  extends: ['plugin:vue/essential', '@vue/airbnb'],
  parserOptions: {
    parser: 'babel-eslint'
  },
  rules: {
    'space-before-blocks': 0,
    'no-console': 0,
    indent: 0,
    quotes: 0,
    'comma-dangle': 0,
    semi: 0,
    'no-unused-vars': 0,
    'vue/no-unused-components': 0
  }
}
